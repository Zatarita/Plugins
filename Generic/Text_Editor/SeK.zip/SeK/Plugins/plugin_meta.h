#ifndef PLUGIN_META_H
#define PLUGIN_META_H

#include <QString>
#include <QStringList>
#include <QFile>
#include <QTextStream>

#include <map>

/// Stores metadata and settings related to the plugin. All settings need to be stored
/// externally in case a setting is changed that causes instability. To do this the *cfg*
/// file was created. \n __An example cfg can be found in the root folder of Plugins/Generic-Plugins.__
struct PluginMeta
{
    PluginMeta() {};

    /// Name of the plugin
    QString Name = "";
    /// Author(s) of the plugin. Must be one line; however, multiple authors can be seperated with a semicolon
    QString Author = "";
    /// Does the plugin support CLI Functionality?
    bool CLISupported = false;

    /// Type of plugin Archive/Data.
    enum PluginFormat
    {
        DATA,
        ARCHIVE
    } Format;

    /// Which file extentions this plugin is designed to open
    QStringList SupportedFormats;

    /// Version of the plugin This is verified with a simple string compare. Even though you can use whichever version convention you like, it is recomended you follow the "Major.Minor.Patch" convention for consistency.
    QString Version = "";
    /// URL To a repo. This will download the cfg file hosted there and validate our current version, against the repo's version. If it doesn't match Autoupdate will replace the cfg, and download the lib pointed by versionControl::Lib as the newer version.
    QString URL = "";
    /// The library file the program looks for when running the plugin (application look for the appropriate extension. Just the file name is required). This should be in the same location as the cfg file; however, it is not required so long as you supply a relative directory from the plugins root directory.
    QString Lib = "";

    /// Settings mapped [name, value] The value needs to be casted if a string value isn't practical.
    std::map<QString, QString> Settings;

    /// Load the settings from a config file
    /// @param path to the config file to be loaded.
    void Load(const QString& path)
    {
        // Really hate loading things like this; however, if I used XML It would be basically
        // uglier than this. So this is the simplist, most eligant way C++ can handle this I guess.

        // Load plugin.cfg with read only permission
        QFile cfg(path);
        if (!cfg.open(QIODevice::ReadOnly | QIODevice::Text))
                return;

        // While there are still lines to read
        while (!cfg.atEnd())
        {
            // Read a line
            QString line = cfg.readLine();

            // Comments and blank lines.
            if(line.contains("#-#"))
            {
                while(true)
                {
                    // If it's the end of the multi-line comment. Break from this cyclical hell.
                    if(cfg.readLine().contains("#-#"))
                        break;
                    // If we've reached the end of the file, then the comment was never closed.
                    if(cfg.atEnd())
                        return; /// \todo Exception handling - Syntax error: Unclosed Multi-line comment
                }
                continue;
            }
            if(line == "\n" || line.contains("#"))
               continue;

            // If it's not blank, split it at the space
            QStringList parameters = line.split(" ");

            // Put the properties into the correct locations.
            if(parameters[0] == "[Format]")
            {
                if(parameters[1].remove("\n").toLower() == "data")
                {
                    Format = PluginFormat::DATA;
                }
                else if(parameters[1].remove("\n").toLower() == "archive")
                {
                    Format = PluginFormat::ARCHIVE;
                }
                else
                {
                    return; /// \todo Exception handling - Syntax error: Unknown format.
                }
                continue;
            }
            if(parameters[0] == "[Name]")
            {
                Name = parameters[1].remove("\n");
                continue;
            }
            if(parameters[0] == "[Author]")
            {
                Author = parameters[1].remove("\n");
                continue;
            }
            if(parameters[0] == "[CLISupport]")
            {
                CLISupported = (parameters[1].toLower() == "true\n") ? true : false;
                continue;
            }
            if(parameters[0] == "[Version]")
            {
                Version = parameters[1].remove("\n");
                continue;
            }
            if(parameters[0] == "[URL]")
            {
                URL = parameters[1].remove("\n");
                continue;
            }
            if(parameters[0] == "[Lib]")
            {
                Lib = parameters[1].remove("\n");
                continue;
            }
            if(parameters[0] == "[Setting]")
            {
                QString buffer = parameters[1].split("=")[0];
                Settings[buffer] = parameters[1].split("=")[1].remove("\n");
                continue;
            }
            if(parameters[0] == "[Extension]")
            {
                SupportedFormats.append(parameters[1].remove("\n"));
            }
        }
    }

    /// Save the plugin settings.
    /// @param path to the where the config file should be saved.
    void Save(const QString& path)
    {
        // Try and open the config file with write permissions
        QFile cfg(path);
        if (!cfg.open(QIODevice::WriteOnly | QIODevice::Text))
                return;

        // If opened, write all the related information
        QTextStream out(&cfg);
        out << "[Name] " << Name << "\n";
        out << "[Author] " << Author << "\n";
        out << "[CLISupport] " << CLISupported << "\n";
        out << "[Version] " << Version << "\n";
        out << "[URL] " << URL << "\n";
        out << "[Lib] " << Lib << "\n";
        for(auto& Setting : Settings)
            out << "[Setting] " << Setting.first << ": " << Setting.second << "\n";
    }
};

#endif // PLUGIN_META_H
