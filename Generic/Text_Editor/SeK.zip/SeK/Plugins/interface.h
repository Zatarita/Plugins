// Interface.h
#ifndef INTERFACE
#define INTERFACE

#include <QObject>
#include <QString>
#include <QWidget>
#include <QFileInfo>

#include "plugin_meta.h"

/// This is a base class that defines an interface for a data oriented plugin
/// The purpose of a plugin like this is to present the contents of a binary file for modification.
///
/// A plugin is accompanied by an cfg file which contains metadata about the plugin. This consists of
/// supported file type, version, version control URL, and much more.
class DataInterface
{
public:
    /// Supplied for compiler compliance. \n
    virtual ~DataInterface() = default;

    /// Attempts to load the file supplied and return a widget we can use to interface with the data. \n *returns __nullptr__ if failure*
    virtual QWidget* Invoke(const QString& path, QWidget* parent = nullptr) = 0;

    /// Attempts to load the raw data supplied and return a widget we can use to interface with the data. \n *returns __nullptr__ if failure*
    virtual QWidget* Invoke(const QByteArray& Data, QWidget* parent = nullptr) = 0;

    /// When runnning the application inside CLI Mode, these are the parameters that get passed to the plugin
    virtual void CLInvoke(const QString& args) = 0;
};

#define DataInterface_iid "SeK.plugins.DataInterface/1.0"
Q_DECLARE_INTERFACE(DataInterface, DataInterface_iid)

/// This is a base class that defines an interface for a archive oriented plugin
/// The purpose of a plugin like this is to present the contents of a archive in the heirarchy view
///
/// A plugin is accompanied by an cfg file which contains metadata about the plugin. This consists of
/// supported file type, version, version control URL, and much more. Similar to DataInterface
class ArchiveInterface
{
public:
    /// Supplied for compiler compliance. \n
    virtual ~ArchiveInterface() = default;


};

#define ArchiveInterface_iid "SeK.plugins.ArchiveInterface/0.1"
Q_DECLARE_INTERFACE(ArchiveInterface, ArchiveInterface_iid)


#endif
