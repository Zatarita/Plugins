#ifndef TXTPLUGINWIDGET_H
#define TXTPLUGINWIDGET_H

#include <QWidget>
#include <QString>
#include <QFile>
#include <QTextStream>
#include <QFileDialog>

#include <QMenuBar>

#include <stdio.h>

namespace Ui {
class TxtPluginWidget;
}

class TxtPluginWidget : public QWidget
{
    Q_OBJECT
    QString OriginalPath;

private slots:
    void Save();
    void SaveAs();
    void CastTo();
public:
    TxtPluginWidget(const QString& Path, QWidget* parent = nullptr);
    TxtPluginWidget(const QByteArray& data, QWidget* parent = nullptr);
    ~TxtPluginWidget();

    QMenuBar* mainMenu = new QMenuBar(this);
    QMenu* File = mainMenu->addMenu("File");
    QMenu* Edit = mainMenu->addMenu("Edit");
    QMenu* Help = mainMenu->addMenu("Help");

    QAction* FileSave;
    QAction* FileSaveAs;
    QAction* FileCast;
    QAction* FileClose;

    QAction* EditUndo;
    QAction* EditRedo;
    QAction* EditCut;
    QAction* EditCopy;
    QAction* EditPaste;
    QAction* EditDelete;
    QAction* EditSelectAll;
    QAction* EditFind;
    QAction* EditFindAll;
    QAction* EditGoto;
    QAction* EditCompare;
    QAction* EditCase;
    QAction* EditPreferences;

    QAction* HelpAbout;
    QAction* HelpReportBug;

    void SetupMenu();

signals:
    /// Used to emit a thread safe signal that the main application can catch and react to.
    void logNotice(const QString& msg);
    /// Used to emit a thread safe signal that the main application can catch and react to.
    void logError(const QString& msg);

    void Invoke(const QByteArray& data, const QString& plugin);

private:
    Ui::TxtPluginWidget *ui;
};

#endif // TXTPLUGINWIDGET_H
