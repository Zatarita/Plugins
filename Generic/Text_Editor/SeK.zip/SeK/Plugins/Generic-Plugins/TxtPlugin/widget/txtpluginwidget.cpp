#include "txtpluginwidget.h"
#include "ui_txtpluginwidget.h"

TxtPluginWidget::TxtPluginWidget(const QString& path, QWidget* parent) :
    QWidget(parent) ,
    ui(new Ui::TxtPluginWidget)
{
    ui->setupUi(this);
    OriginalPath = path;

    ui->MenuBar->addWidget(mainMenu);
    SetupMenu();

    ui->Bookmarks->setHidden(true);

    // Connect to the main application to use the log.
    connect(this, SIGNAL(logNotice(QString)), parent, SLOT(logNotice(QString)));
    connect(this, SIGNAL(logError(QString)), parent, SLOT(logError(QString)));
    connect(this, SIGNAL(Invoke(QByteArray, QString)), parent, SLOT(Invoke(QByteArray, QString)));

    // Try and open the config file with write permissions
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
            return;

    // If opened, write all the related information
    QTextStream out(&file);
    ui->textEdit->setText(out.readAll());
}

TxtPluginWidget::TxtPluginWidget(const QByteArray& Data, QWidget* parent) :
    QWidget(parent) ,
    ui(new Ui::TxtPluginWidget)
{
    ui->setupUi(this);

    ui->MenuBar->addWidget(mainMenu);
    SetupMenu();

    ui->Bookmarks->setHidden(true);

    // Connect to the main application to use the log.
    connect(this, SIGNAL(logNotice(QString)), parent, SLOT(logNotice(QString)));
    connect(this, SIGNAL(logError(QString)), parent, SLOT(logError(QString)));
    connect(this, SIGNAL(Invoke(QByteArray, QString)), parent, SLOT(Invoke(QByteArray, QString)));

    ui->textEdit->setText(Data);
}

TxtPluginWidget::~TxtPluginWidget()
{
    delete ui;
}

void TxtPluginWidget::SetupMenu()
{
    FileSave = File->addAction("Save");
    connect(FileSave, SIGNAL(triggered()), this, SLOT(Save()));
    FileSaveAs = File->addAction("Save As..");
    connect(FileSaveAs, SIGNAL(triggered()), this, SLOT(SaveAs()));
    FileCast = File->addAction("Cast To");
    connect(FileCast, SIGNAL(triggered()), this, SLOT(CastTo()));
    File->addSeparator();
    FileClose = File->addAction("Close");

    EditUndo = Edit->addAction("Undo");
    EditRedo = Edit->addAction("Redo");
    Edit->addSeparator();
    EditCut = Edit->addAction("Cut");
    EditCopy = Edit->addAction("Copy");
    EditPaste = Edit->addAction("Paste");
    EditDelete = Edit->addAction("Delete");
    Edit->addSeparator();
    EditSelectAll = Edit->addAction("Select All");
    Edit->addSeparator();
    EditFind = Edit->addAction("Find");
    EditFindAll = Edit->addAction("Find All");
    EditGoto = Edit->addAction("Goto Line");
    Edit->addSeparator();
    EditCompare = Edit->addAction("Compare");
    EditCase = Edit->addAction("Case");
    Edit->addSeparator();
    EditPreferences = Edit->addAction("Preferences");

    HelpAbout = Help->addAction("About");
    Help->addSeparator();
    HelpReportBug = Help->addAction("Report a bug");
}

void TxtPluginWidget::Save()
{
    QString path;
    // If no path was passed, attempt to save using the original file path.
    if(path == "")
        path = OriginalPath;
    else
        path = QFileDialog::getSaveFileName(this, tr("Save File"), "", "All Types (*.*)");

    // Save the data
    QFile outfile(path);
    outfile.open(QIODevice::WriteOnly | QIODevice::Text);
    QTextStream out(&outfile);
    out << ui->textEdit->toPlainText();
    outfile.close();
}

void TxtPluginWidget::SaveAs()
{
    QString path = QFileDialog::getSaveFileName(this, tr("Save File"), "", "All Types (*.*)");

    // Save the data
    QFile outfile(path);
    outfile.open(QIODevice::WriteOnly | QIODevice::Text);
    QTextStream out(&outfile);
    out << ui->textEdit->toPlainText();
    outfile.close();
}

void TxtPluginWidget::CastTo()
{
    emit Invoke(ui->textEdit->toPlainText().toLocal8Bit(), "txt");
}
