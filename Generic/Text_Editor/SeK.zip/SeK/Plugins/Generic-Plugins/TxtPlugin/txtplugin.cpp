#include "txtplugin.h"


QWidget* TxtPlugin::Invoke(const QString& args, QWidget* parent)
{
    QStringList arguments = args.split(" ");
    if(arguments.size() < 1)
        return nullptr;

    return new TxtPluginWidget(arguments[0], parent);
}

QWidget* TxtPlugin::Invoke(const QByteArray& data, QWidget* parent)
{
    return nullptr;
}

// Unimplimented. No CLI Support
void TxtPlugin::CLInvoke(const QString& args) {}
