#ifndef TXTPLUGIN_H
#define TXTPLUGIN_H

#include "plugin_meta.h"
#include "interface.h"
#include "widget/txtpluginwidget.h"

#define TxtPlugin_iid "SeK.Plugins.Generic.TxtPlugin"


class TxtPlugin : public QObject, public DataInterface
{
    Q_OBJECT
    Q_PLUGIN_METADATA(IID TxtPlugin_iid FILE "TxtPlugin.json")
    Q_INTERFACES(DataInterface)

public:
    TxtPlugin(){};
    ~TxtPlugin(){};

private:
    /// DataInterface definitions
    QWidget* Invoke(const QString& args, QWidget* parent = nullptr) override;
    QWidget* Invoke(const QByteArray& Data, QWidget* parent = nullptr) override;
    void CLInvoke(const QString& args) override;
};

#endif // TXTPLUGIN_H
