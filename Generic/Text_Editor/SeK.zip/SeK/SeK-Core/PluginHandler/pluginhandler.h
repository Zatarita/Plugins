#ifndef PLUGINHANDLER_H
#define PLUGINHANDLER_H

#include <QObject>
#include <QWidget>
#include <QPluginLoader>
#include <QMap>
#include <QDirIterator>
#include <QFile>
#include <QTextStream>
#include <QFileInfo>
#include <QNetworkReply>
#include <QNetworkAccessManager>
#include <QTemporaryFile>

#include "../../Plugins/interface.h"
#include "../../Plugins/plugin_meta.h"


/// System dependant library extension
#ifdef _WIN32
    static QString LIBRARY_EXTENSION = ".dll"
#else
    static QString LIBRARY_EXTENSION = ".so";
#endif

/**
 * @brief The PluginHandler class
 *
 * Responsible for all aspects of plugin management.
 * On load it will scan the plugins folder recursively for available plugins with *ScanPlugins()*, and then *CheckForUpdates()*.
 * If updates are available it will download and install the new version. After updating *LoadPlugin(const QString& extension)*
 * will attempt to load the plugin and populate *Plugins*. This maps __file extension__ to __plugin handle__. Plugins are then
 * accessed with the "[]" operator
 */
class PluginHandler : public QWidget
{
    Q_OBJECT
    /// Maps the supported format to the corresponding plugin
    QMap<QString, DataInterface*> Plugins;
    QMap<QString, ArchiveInterface*> Archives;

public:
    explicit PluginHandler(QWidget *parent = nullptr);

    /// Will scan the plugins folder recursively for any config file and call *LoadPlugin()*
    void ScanPlugins();

    /// Handler will download a copy of the plugin config from source control (if a URL was supplied). It will check the version numbers against each other, and if they don't match the newer version will be downloaded in it's place.
    /// @param meta PluginMeta to check against for update.
    void CheckForUpdates(const PluginMeta& meta);

    /// Will attempt to load a library specified inside of a cfg file.
    /// @param path to the library. Supplied inside the config file stripped of file extension
    /// @return handle for the plugin interface
    DataInterface* LoadPlugin(const QString& path);

    /// Will attempt to load a library specified inside of a cfg file.
    /// @param path to the library. Supplied inside the config file stripped of file extension
    /// @return handle for the plugin interface
    ArchiveInterface* LoadArchive(const QString& path);

    /** Return the plugin instance that can load this extension.
     *  @param extension to load
     *  @return DataInterface* instance, if one exists; else, nullptr. */
    DataInterface* operator[] (const QString& extension);

    QStringList PluginNames();

signals:
    /// Used to propagate logs to the main application.
    /// @param msg - The message to be displayed
    void logNotice(const QString&);

    /// Used to propagate logs to the main application.
    /// @param msg - The message to be displayed
    void logError(const QString&);
};

#endif // PLUGINHANDLER_H
