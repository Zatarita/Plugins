#include "pluginhandler.h"

PluginHandler::PluginHandler(QWidget *parent) : QWidget(parent)
{
}

void PluginHandler::ScanPlugins()
{
    DataInterface* PluginBuffer;
    ArchiveInterface* ArchiveBuffer;
    QDirIterator it("Plugins", QStringList() << "*.cfg", QDir::Files, QDirIterator::Subdirectories);
    while (it.hasNext())
    {
        QString path = it.next();
        QFileInfo PathInfo(path);


        // attempt to load a config file. then check for updates
        emit logNotice("Loading config file: " + path);
        PluginMeta cfgFile;
        cfgFile.Load(path);

        emit logNotice("Checking " + cfgFile.Name + " for updates: (" + cfgFile.URL + ")\n\t - Version: " + cfgFile.Version);
        CheckForUpdates(cfgFile);

        emit logNotice("Loading plugin: " + cfgFile.Name);
        if(!cfgFile.Lib.isEmpty())
            if(cfgFile.Format == PluginMeta::PluginFormat::DATA)
                PluginBuffer = LoadPlugin(PathInfo.absolutePath() + "/" + cfgFile.Lib + LIBRARY_EXTENSION);
            else
                ArchiveBuffer = LoadArchive(PathInfo.absolutePath() + "/" + cfgFile.Lib + LIBRARY_EXTENSION);
        else
        {
            emit logError(QString("\tUnable to load plugin: ") + cfgFile.Name + "\n\tconfig didn't specify a library.");
            continue;
        }
        // Load plugin would of logged the error. We just need to verify
        if(PluginBuffer == nullptr && ArchiveBuffer == nullptr)
            continue;

        if(cfgFile.Format == PluginMeta::PluginFormat::ARCHIVE)
        {
            emit logNotice("Loaded Archive Support: " + cfgFile.SupportedFormats[0]);
            continue;
        }

        emit logNotice("Linking plugin to file format");
        for(QString& format: cfgFile.SupportedFormats)
        {
            emit logNotice(QString(" - ") + format);
            Plugins[format] = PluginBuffer;
        }
    }
}

void PluginHandler::CheckForUpdates(const PluginMeta& meta)
{
}

DataInterface* PluginHandler::LoadPlugin(const QString& path)
{
    if(!QFileInfo(path).exists())
    {
        emit logError("\tUnable to open plugin: Library path is invalid or wasn't build for this system architecture");
        return nullptr;
    }

    // Attempt to load the library
    QPluginLoader test(path);
    QObject* instance = nullptr;

    if(test.load())
        instance = test.instance();
    else
        emit logError("\tUnable to load plugin: Error while loading library.");

    // If successful, cast to plugin interface.
    DataInterface* object = qobject_cast<DataInterface *>(instance);
    if(object == nullptr)
    {
        emit logError("\tUnable to load the plugin: Interface not valid.");
        return nullptr;
    }

    // If all went well, return the plugin object.
    return object;
}

ArchiveInterface* PluginHandler::LoadArchive(const QString& path)
{
    return nullptr;
}

DataInterface* PluginHandler::operator[] (const QString& name)
{
    // If the format exists, return the plugin that can handle it.
    if(Plugins.contains(name))
        return Plugins[name];
    else
        return nullptr;
}

QStringList PluginHandler::PluginNames()
{
    return Plugins.keys();
}
