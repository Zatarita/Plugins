#include "core.h"
#include "ui_core.h"

Core::Core(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Core)
{
    ui->setupUi(this);

    connect(&Plugins, SIGNAL(logNotice(QString)), this, SLOT(logNotice(QString)));
    connect(&Plugins, SIGNAL(logError(QString)), this, SLOT(logError(QString)));

    Plugins.ScanPlugins();
    m_DockManager = new ads::CDockManager(this);

    ads::CDockWidget* DockWidget = new ads::CDockWidget("Heirarchy");
    DockWidget->setWidget(ui->splitter);
    m_DockManager->addDockWidget(ads::RightDockWidgetArea, DockWidget);

    ui->splitter->setSizes({450, 150});

    Model->setRootPath(QDir::currentPath());
    ui->treeView->setModel(Model);

    this->setWindowTitle("SeK");
    SetupContextMenus();
}

Core::~Core()
{
    delete ui;
}

void Core::logNotice(const QString& msg)
{
    // Split any newline characters out
    QStringList lines = msg.split("\n");
    for(QString line : lines)
    {
        ui->log->insertHtml(notifyHtml + line + endHtml);
        ui->log->insertPlainText("\n");
    }
}

void Core::logError(const QString& msg)
{
    QStringList lines = msg.split("\n");
    for(QString line : lines)
    {
        ui->log->insertHtml(alertHtml + line + endHtml);
        ui->log->insertPlainText("\n");
    }
}

void Core::Invoke(const QString& path, QString plugin)
{
    // Get the file info for the path, check if it is a directory. If it isn't strip out the extension
    QFileInfo info(path);
    if(info.isDir())
        return;
    QString format = info.completeSuffix();

    // Next verify we have a plugin that can handle loading the plugin
    DataInterface* hPlugin = Plugins[format];
    if(hPlugin == nullptr)
        return;  /// \todo open "open with" dialog here. No supported plugin found.

    // Try to get the widget from the plugin
    QWidget* widget = Plugins[format]->Invoke(path, this);
    if(widget== nullptr)
        return;

    // If all of that is successful do the thing.
    ads::CDockWidget* DockWidget = new ads::CDockWidget("Text Editor");
    DockWidget->setWidget(widget);
    m_DockManager->addDockWidget(ads::RightDockWidgetArea, DockWidget);
}

void Core::Invoke(const QByteArray& data, QString plugin)
{
    // Try to get the widget from the plugin
    QWidget* widget = Plugins[plugin]->Invoke(QByteArray(data), this);
    if(widget== nullptr)
        return;

    // If all of that is successful do the thing.
    ads::CDockWidget* DockWidget = new ads::CDockWidget("Text Editor");
    DockWidget->setWidget(widget);
    m_DockManager->addDockWidget(ads::RightDockWidgetArea, DockWidget);
}

void Core::on_treeView_doubleClicked(const QModelIndex &index)
{
    Invoke(Model->filePath(index));
}

void Core::SetupContextMenus()
{
    // Add the actions to the respective menus
    FileContext.addAction(FileContext.FileOpen);
    FileContext.addAction(FileContext.FileOpenWith);
    FileContext.addSeparator();
    FileContext.addAction(FileContext.FileCut);
    FileContext.addAction(FileContext.FileCopy);
    FileContext.addAction(FileContext.FileRename);
    FileContext.addAction(FileContext.FileDelete);

    DirectoryContext.addAction(DirectoryContext.DirCut);
    DirectoryContext.addAction(DirectoryContext.DirCopy);
    DirectoryContext.addAction(DirectoryContext.DirPaste);
    DirectoryContext.addAction(DirectoryContext.DirDelete);
    DirectoryContext.addSeparator();
    DirectoryContext.addAction(DirectoryContext.DirExpand);
    DirectoryContext.addAction(DirectoryContext.DirCollapse);
}

void Core::on_treeView_customContextMenuRequested(const QPoint &pos)
{
    QModelIndex index = ui->treeView->indexAt(pos);
    QFileInfo Finfo(Model->filePath(index));
    if(Finfo.isDir())
        DirectoryContext.popup(ui->treeView->viewport()->mapToGlobal(pos));
    else
        FileContext.popup(ui->treeView->viewport()->mapToGlobal(pos));
}
