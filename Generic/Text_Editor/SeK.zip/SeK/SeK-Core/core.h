#ifndef CORE_H
#define CORE_H

#include <QMainWindow>
#include <QObject>
#include <QPluginLoader>
#include <QMessageBox>
#include <QDockWidget>
#include <QFileSystemModel>
#include <QMap>
#include <QMenu>
#include <QAction>

#include "DockManager.h"
#include "DockWidget.h"

#include "PluginHandler/pluginhandler.h"

#include "../Plugins/interface.h"

QT_BEGIN_NAMESPACE
namespace Ui { class Core; }
QT_END_NAMESPACE

/// The base application.
/// A canvas that the plugins use to display widgets used to edit raw data
class Core : public QMainWindow
{
    Q_OBJECT
    PluginHandler Plugins;
    QFileSystemModel *Model = new QFileSystemModel;
    ads::CDockManager* m_DockManager;

    const QString alertHtml = "<font color=\"DeepPink\">";
    const QString notifyHtml = "<font color=\"Lime\">";
    const QString endHtml = "</font>";

    /// Context menu for right clicking on a file in the tree view.
    struct : public QMenu
    {
        QAction* FileOpen = new QAction("Open");
        QAction* FileOpenWith = new QAction("Open With");
        QAction* FileCut = new QAction("Cut");
        QAction* FileCopy = new QAction("Copy");
        QAction* FileRename = new QAction("Rename");
        QAction* FileDelete = new QAction("Delete");
    } FileContext;

    /// Context menu for right clicking on a directory in the tree view.
    struct : public QMenu
    {
        QAction* DirCut = new QAction("Cut");
        QAction* DirCopy = new QAction("Copy");
        QAction* DirPaste = new QAction("Paste");
        QAction* DirDelete = new QAction("Delete");
        QAction* DirRename = new QAction("Rename");
        QAction* DirExpand = new QAction("Expand");
        QAction* DirCollapse = new QAction("Collapse");
    } DirectoryContext;

    /// Context menu for right clicking on an archive in the tree view.
    struct : public QMenu
    {
    } ArchiveContext;


    /// Called at initialize. Sets up the right click menus for the heirarchy, log view, and command entry
    void SetupContextMenus();
    /// Called at initialize. Sets up the menu bar for the primary window.
    void SetupMenuBar();
    /// Called at intialize. Sets up the heirarchy, log view and command entry.
    void SetupWidgets();
public:
    Core(QWidget *parent = nullptr);
    ~Core();

private:
    Ui::Core *ui;

signals:
    /// Called when any message is pushed to the log. notice, or warning.
    /// @param msg - Message that was written to the log.
    void logWritten(const QString& msg);

public slots:
    /// Forwards a message to the log handler. \n *May contain HTML formatting*
    /// @param msg - The message that will be written.
    void logNotice(const QString& msg);
    /// Forwards an error to the log handler. \n *May contain HTML formatting* \n Default format is red text.
    /// @param msg - The message that will be written.
    void logError(const QString& msg);

    /// Attempts to use a plugin to open a file.
    /// @param path - The path to the file the plugin is to try and open.
    /// @param plugin - Attempt to open the file with a specific plugin. If left blank, it will scan for an appropriate one.
    void Invoke(const QString& path, QString plugin = "");

    /// Attempts to use a plugin to open Raw data.
    /// @param path - The path to the file the plugin is to try and open.
    /// @param plugin - Attempt to open the file with a specific plugin. If left blank, it will scan for an appropriate one.
    void Invoke(const QByteArray& data , QString plugin = "");

    /// Called when File>Open, or Right-Click>Open, is pressed /n Displays a File Dialog to get a file path, and then invokes the selected file to load.
    //void OpenRequested();

    /// Called when File>Open As, or Right-Click>Open As, is pressed. \n Displays a File Dialog to get a file path, and then invokes a specific plugin to try and load it.
    //void OpenWithRequested(QString);

    /// Called when Plugin>Manage is called \n Opens a dialog that allows us to manage currently installed plugins
    //void PluginManageRequested();

    /// Called when Plugin>Settings is called. \n Opens a tab for us to edit sittings relating to each plugin.
    //void PluginSettingsRequested();

private slots:
    /// Called when an item is doubleclicked in the tree view
    /// @param index - Index of the selected item.
    void on_treeView_doubleClicked(const QModelIndex& index);
    void on_treeView_customContextMenuRequested(const QPoint &pos);
};
#endif // CORE_H
