# Rebuild documentation for each piece.
doxygen SeK
doxygen Plugins/Plugins
